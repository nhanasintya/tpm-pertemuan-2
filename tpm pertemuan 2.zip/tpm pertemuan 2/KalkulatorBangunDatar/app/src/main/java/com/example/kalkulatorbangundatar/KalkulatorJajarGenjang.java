package com.example.kalkulatorbangundatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class KalkulatorJajarGenjang extends AppCompatActivity {
    private Button btnHasil;
    private TextView tvHasil;
    private EditText etAlas, etTinggi;
    private Double sHasil = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kalkulator_jajar_genjang);

        etAlas = findViewById(R.id.et_alas);
        etTinggi = findViewById(R.id.et_tinggi);
        btnHasil = findViewById(R.id.btn_hasil);
        tvHasil = findViewById(R.id.tv_hasil);

        btnHasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Double alas = Double.parseDouble(etAlas.getText().toString());
                    Double tinggi = Double.parseDouble(etTinggi.getText().toString());

                    Double hasil = alas * tinggi ;
                    tvHasil.setText(String.valueOf(hasil));
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), " ada yang ERROR", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
